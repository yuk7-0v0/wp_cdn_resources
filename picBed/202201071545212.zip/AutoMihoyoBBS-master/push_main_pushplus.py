import sys
import time
import random
import subprocess
from request import http

def pushpush():
    SendKey = "d5c740d241d64dd3af92eedbcaf3966c"
    send_Url = "http://www.pushplus.plus/send"

    python_Path = sys.executable

    run_ShellCommand = python_Path + " main_multi.py autorun"

    for i in range(2):
        opt_id, opt_info = subprocess.getstatusoutput(run_ShellCommand)
        if opt_id == 0:
            break
        time.sleep(random.randint(30, 70))

    if opt_id != 0:
        print("Error!")
        http.post(
            url=send_Url,
            data={
                "token": SendKey,
                "title": "米游社脚本执行出错！",
                "content": "这里是运行相关日志：\r\n" + opt_info,
                'topic': 'OOOOP'
            }
        )
    else:
        http.post(
            url=send_Url,
            data={
                "token": SendKey,
                "title": "米游社脚本执行成功",
                "content": "这里是运行相关日志：\r\n" + opt_info,
                'topic': 'OOOOP'
            }
        )
        print("OK!")

if __name__ == '__main__':
    pushpush()
    exit(0)